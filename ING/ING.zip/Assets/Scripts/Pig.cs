﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace Zoo
{
    class Pig : Animal, IHerbivore, ICarnivore, ITrick
    {

    }
}
