﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace Zoo
{
    class Tiger : Animal, ITrick, ICarnivore
    {
       
    }
}
