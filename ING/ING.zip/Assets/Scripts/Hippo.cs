﻿using UnityEngine;
using UnityEngine.UI;

namespace Zoo
{
    class Hippo : Animal, IHerbivore
    {

    }
    
}
