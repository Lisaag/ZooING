﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

namespace Zoo
{
    public class Dog : Animal, ICarnivore, ITrick
    {

    }
}
