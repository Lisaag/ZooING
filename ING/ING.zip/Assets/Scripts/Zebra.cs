﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace Zoo
{
    class Zebra : Animal, IHerbivore
    {
        
    }
}
