﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Zoo
{
    public class Debugger : MonoBehaviour
    {
        public void ShowText()
        {
            
        }
    }
}