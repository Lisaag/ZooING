Opdracht:
- Maak de "game" af.
- Refactor eventueel de code (denk goed na over de class structure).
	- Probeer er voor de zorgen dat je bijvoorbeeld geen EatMeat methode kan aanroepen op een Zebra object.
- Voeg 2 nieuwe dieren toe.

Wat moet er allemaal kunnen:
- als je op Give leaves drukt krijgen alle herbivores leaves (en hun teksballon aanzetten).
- als je op Give meat drukt krijgen alle carnivores meat (en hun teksballon aanzetten).
- als je op Tricks drukt doen alle dieren die dat kunnen hun trucje.
- als je op Hello klikt zonder dat er een naam is ingevuld zeggen alle dieren hallo.
- als er wel een naam is ingevuld zegtalleen dat dier hallo (de andere knoppen doen het nog wel voor alle dieren).